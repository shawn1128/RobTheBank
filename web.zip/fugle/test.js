var records = {"close" : 1};
console.log(!records["open"]);