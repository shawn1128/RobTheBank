module.exports = { 
	token: '9e325cdd419b6701be7edb38d895f940ef9b294ef90a6c2ae3366fc0f545ec27',
	dbhost: 'robthebank.cdmb6fbybksy.us-east-1.rds.amazonaws.com',
	dbuser: 'StockEzEz',
	dbpassword: 'robthebankwithlin',
	dbname: 'RobTheBank'
};