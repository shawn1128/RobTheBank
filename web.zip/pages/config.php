<?php
		include "../dbinfo.inc"; 
		$connection = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD)or die('Error with MySQL connection');
?>